<nav class="navbar navbar-default" style="background-color:#e5e0e0;">
<div class="container-fluid" style="height:40;">
<div class="navbar-header">
<button type="button" class="btn btn-success" style="height:30px; background-color:teal; margin-top:15px;"><a href="#top" style="color:white;"><h5 style="margin-top:0px;">NIT SIKKIM</h5></a></button>
</div>
<div>
<ul class="nav navbar-nav">

<li style="padding:18px;">Disclaimer</li>
<li style="padding:18px;">Wikipedia</li>
<li style="padding:18px;">Nobel Laureates</li>

</ul>
<ul class="nav navbar-nav navbar-right">
<li style="padding:18px;">WDC</li>
</ul>
</div>

</div>
<p style="text-align:center;">Copyright © 2017 NIT Sikkim. All Rights Reserved</p>
</nav>
</div>
</body>
</html>
